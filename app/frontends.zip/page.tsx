import Image from "next/image";
import styles from "./page.module.css";
import UserLanding from "./user/page";

export default function Home() {
  return (
   <>
      <UserLanding/>
   </>
  );
}
